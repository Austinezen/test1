/* My first socket program */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <linux/types.h>
#include <asm/types.h>
#include <linux/socket.h>
#include <asm/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "server_framework.h"

#define SERVER_PORT 1070
struct service_management_message smm;
char *s = "/usr/bin/fuxfs_server";
char *sn = "network_memory_server";

/* change the program to connect to any device */

int main(argc, argv)
     int argc;
     char **argv;
     
{
  int n;
  int socksend_fd;
  struct sockaddr_in msock, csock;
  int len = sizeof(struct sockaddr_in);
  int count = 0;
  char cbuf[100];

  bzero((char *)&csock, sizeof(struct sockaddr_in));
  bzero((char *)&msock, sizeof(struct sockaddr_in));

  msock.sin_family = AF_INET;
  msock.sin_addr.s_addr = 0;
  msock.sin_port = 0;

  if((socksend_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
      printf("%s: unable to get a socket\n", argv[0]);
      exit(-1);
    }

  if((bind(socksend_fd, (struct sockaddr *)&msock, len)) < 0)
    {
      printf("%s: unable to bind to a local socket\n",argv[0]);
      exit(-1);
    }

  /* convert the first argument to something I can use */
    
  csock.sin_family = AF_INET;
  /* csock.sin_addr.s_addr = 0;  /* connecting to local machine */
  csock.sin_addr.s_addr = inet_addr(argv[1]);
  csock.sin_port = htons(SERVER_PORT);

  if((connect(socksend_fd, (struct sockaddr *)&csock, sizeof(struct sockaddr_in))) < 0)
    {
      printf("%s: unable to connect to server\n", argv[0]);
      exit(-1);
    }
  printf("connected to the server\n");
  bzero((char *)&smm, sizeof(struct service_management_message));
  smm.command = REGISTER_SERVICE;
  smm.result = -1;
  strcpy(smm.serv_mec.archive_executable, s);
  smm.serv_mec.archive_executable_len = strlen(s);
  strcpy(smm.serv_mec.service_name, sn);
  smm.serv_mec.service_name_len = strlen(sn);
  smm.serv_mec.service_version = 0;
  smm.serv_mec.maximum_number_servers = 1;
  smm.serv_mec.current_number_servers = 0;
  smm.serv_mec.service_server_list.count=0;
  smm.serv_mec.service_resources_required.CPU = 1; /* Assum programs does not use threads*/
  smm.serv_mec.service_resources_required.memory = 400 ; /*Megabytes (using physical memory) */
  smm.serv_mec.service_resources_required.network = 100  ;/* Mbps */
  smm.serv_mec.service_resources_required.storage = 10  ;/* Gigabytes */
  smm.serv_mec.service_qos.latency = 100000; /* 100 milliseconds of latency */
  smm.serv_mec.service_qos.bandwidth = 100; /* Mbps */
  smm.serv_mec.service_qos.jitter = 100000 ; /* 100 milliseconds of Jitter */
  smm.serv_mec.service_qos.reliability = 100 ; /* Totally reliable */
  send(socksend_fd, (char *)&smm, sizeof(struct service_management_message), 0);
  
  n = recv(socksend_fd, (char *)&smm, sizeof(struct service_management_message), 0);
  
  if (n > 0)
 {  
   printf("Result returned: %d\n", smm.result);
   printf("Service Registered:   Service_id %d\n", smm.serv_mec.service_id);
 }
else 
 { 
  printf("Unable recive from Service Management framework");
 }
       
      /*bzero((char *)cbuf, 100);
      sprintf(cbuf,"%s the count is %d\n", argv[0], count);
      send(socksend_fd, cbuf, 100, 0);
      count++;*/
    //  sleep(1);
    //}
  close(socksend_fd);
  exit(0);
 }

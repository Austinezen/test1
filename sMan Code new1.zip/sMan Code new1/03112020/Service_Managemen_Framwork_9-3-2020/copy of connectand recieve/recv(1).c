/* My first socket program */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <linux/types.h>
#include <asm/types.h>
#include <linux/socket.h>
#include <asm/socket.h>
#include <netinet/in.h>

#define SERVER_PORT 1067

int main(argc, argv)
     int argc;
     char **argv;
{
  int sockrecv_fd, sockacc_fd;
  struct sockaddr_in csock, rsock;
  unsigned int len = sizeof(struct sockaddr_in);
  unsigned int *plen = &len;
  char cbuf[100];
  int n;

  bzero((char *)&csock, sizeof(struct sockaddr_in));
  csock.sin_family = AF_INET;
  csock.sin_addr.s_addr = 0;
  csock.sin_port = htons(SERVER_PORT);

  if((sockrecv_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
      printf("%s: unable to get a socket\n", argv[0]);
      exit(-1);
    }

  if((bind(sockrecv_fd, (struct sockaddr *)&csock, len)) < 0)
    {
      printf("%s: unable to bind to server's address\n");
      exit(-1);
    }

  if((listen(sockrecv_fd, 5)) < 0)
    {
      printf("%s: couldn't listen on this socket\n", argv[0]);
      exit(-1);
    }

  if((sockacc_fd = accept(sockrecv_fd, (struct sockaddr *)&rsock, plen)) < 0)
    {
      printf("%s: accept failed\n", argv[0]);
      exit(-1);
    }

  printf("%s connected to client\n", argv[0]);
  for(;;)
    {
      n = recv(sockacc_fd, cbuf, 100, 0);
      if(n <= 0 )
	{
	  printf("%s: cannot receive on this socket\n", argv[0]);
	  exit(-1);
	}
      printf("%s",cbuf);
    }
  close(sockacc_fd);
  close(sockrecv_fd);
  exit(0);
}

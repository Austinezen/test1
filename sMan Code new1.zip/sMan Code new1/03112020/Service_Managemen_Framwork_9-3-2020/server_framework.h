
/* Server frame work structure */

/*commands to the service*/
#define REGISTER_SERVICE 1
#define REQUEST_SERVICE 2
#define MIGRATE_SERVICE 3 /* NI - NOT IMPLEMENTED */
#define DEREGISTER_SERVICE 4

struct resources_required {
	unsigned int CPU;    /* Number of Cores, Clock Speed */
    	unsigned int memory; //MBs of Memory
	unsigned int network; // Mbps requirement)
	unsigned int storage;  //(Gigabits Requirement)
 };
 
struct qos {
	 int latency; /* in microseconds */
	 int bandwidth; /* Mbps */
	 int jitter;    /* in microseconds */
	 int reliability; /* Out of 100 where 100 is total reliability */
 };
	 
	 
struct restriction_list {
	int security_level; //(minimum Security level)
	struct qos qos_min;   //(minimum)
	int restrict_array_count;
	int location [10]; //(restricted Networks)
	int maximum_replication; //(how much replica count)
 };

 struct client {		
	unsigned int client_id; //(identifies clients to the service)
	unsigned int node_id;
	unsigned int location_id; // (IP address)
	struct client *next;
	struct client *prev;
	
 };
 
  struct client_list{
	  
	 struct client *head;
	 struct client *tail;
	 int count;
  };
	  
 struct server {
	char executable [100]; // file name where the binary is to be found 
	unsigned int server_id;
	unsigned int server_location; //(IP address)
	unsigned short server_port;
	unsigned char server_version;
	unsigned char server_status; //(running, initiated, executable)
	unsigned short maximum_server_load;
	unsigned short current_load;
	unsigned short maximum_client_on_server;
	struct client_list server_client;
	struct server *next;
	struct server *prev;
	
	  // define as a service { unsigned short list_of_current_running_servers;}
 };
 struct server_list{
	  
	 struct server *head;
	 struct server *tail;
	 int count;
  };
  

 
/*struct qos {
	unsigned int bandwidth_requirement;
	unsigned int latency_requirement;
	unsigned int jitter_requirement;
	unsigned int reliability_requirement; };*/
 
 
struct network_requirement {
	unsigned char types_of_handover_support; //(Proactive or Reactive)
	unsigned char signalling_from_network_layer; //(L2 Trigger)
	unsigned char list_of_network_interfaces; //(e.g. Heterogeneous)
	unsigned char list_of_transport_protocol; //(e.g. TCP, UDP, and SLTP)
 };
 
struct restrictions_max {
	/*unsigned short Minimum_Security_level;
	unsigned short Location_Restrictions;*/
	unsigned short max_CPU;
	unsigned short max_memory;
	unsigned short max_storage;
 };
 
struct recovery_mechanism {
	unsigned short shutdown;
	unsigned short restart;
 };
 
struct service_min {
	unsigned int server_id;
	unsigned int ip_address;
}; 
 
 struct service {
	 char archive_executable[100];
	 char service_name [100];
	 unsigned char archive_executable_len;
	 unsigned char service_name_len; 
	 unsigned int service_id;
	 unsigned int service_version; /* if its "0" - it is a latest version! */
	 unsigned int maximum_number_servers; /* 1 */
	 unsigned int current_number_servers; /* 0 */
	 struct server_list service_server_list; /* NULL*/
	 struct resources_required service_resources_required;
     	 struct qos service_qos; 
    	 struct restriction_list service_restriction_list;
	 struct network_requirement service_network_requirments;
	 struct restrictions_max service_restrictions_max;
	 struct recovery_mechanism service_recovery_mechanism;
	 struct service *next;
	 struct service *prev;
 };
 
  struct service_list{
	  
	 struct service *head;
	 struct service *tail;
	 int count;
  };
  
  
  struct service_management_framework {
          int smf_name_len;
	  char smf_name [100];
	 unsigned int status;// status 0 = down, 1= starting , 2 = up , 3 = closing, 4 = closed
	 struct service_list list_managed_services;
     int number_of_request;
	 unsigned int port_number;
  };
  
  struct service_management_message {

	int command;
	int result;
	struct service serv_mec; /*mechanism*/
	
	
};









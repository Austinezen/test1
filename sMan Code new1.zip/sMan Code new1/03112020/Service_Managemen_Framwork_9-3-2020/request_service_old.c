/* My first socket program */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <linux/types.h>
#include <asm/types.h>
#include <linux/socket.h>
#include <asm/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>


#define SERVER_PORT 1070

/* change the program to connect to any device */

int main(argc, argv)
     int argc;
     char **argv;
{
  int socksend_fd;
  struct sockaddr_in msock, csock;
  int len = sizeof(struct sockaddr_in);
  int count = 0;
  char cbuf[100];

  bzero((char *)&csock, sizeof(struct sockaddr_in));
  bzero((char *)&msock, sizeof(struct sockaddr_in));

  msock.sin_family = AF_INET;
  msock.sin_addr.s_addr = 0;
  msock.sin_port = 0;

  if((socksend_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
      printf("%s: unable to get a socket\n", argv[0]);
      exit(-1);
    }

  if((bind(socksend_fd, (struct sockaddr *)&msock, len)) < 0)
    {
      printf("%s: unable to bind to a local socket\n",argv[0]);
      exit(-1);
    }

  /* convert the first argument to something I can use */
    
  csock.sin_family = AF_INET;
  /* csock.sin_addr.s_addr = 0;  /* connecting to local machine */
  csock.sin_addr.s_addr = inet_addr(argv[1]);
  csock.sin_port = htons(SERVER_PORT);

  if((connect(socksend_fd, (struct sockaddr *)&csock, sizeof(struct sockaddr_in))) < 0)
    {
      printf("%s: unable to connect to server\n", argv[0]);
      exit(-1);
    }
  printf("connected to the server\n");
  for(;;)
    {
      bzero((char *)cbuf, 100);
      sprintf(cbuf,"%s the count is %d\n", argv[0], count);
      send(socksend_fd, cbuf, 100, 0);
      count++;
    //  sleep(1);
    }
  close(socksend_fd);
  exit(0);
}
